---
name: Artisan Heritage System
colors:
  surface: '#fff8f5'
  surface-dim: '#ebd6c9'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff1ea'
  surface-container: '#ffeade'
  surface-container-high: '#fae4d7'
  surface-container-highest: '#f4ded2'
  on-surface: '#241912'
  on-surface-variant: '#4f453f'
  inverse-surface: '#3b2e25'
  inverse-on-surface: '#ffede4'
  outline: '#81756e'
  outline-variant: '#d3c4bc'
  surface-tint: '#72594a'
  primary: '#0d0300'
  on-primary: '#ffffff'
  primary-container: '#2c1a0e'
  on-primary-container: '#9d806f'
  inverse-primary: '#e1c0ad'
  secondary: '#8c5008'
  on-secondary: '#ffffff'
  secondary-container: '#ffb065'
  on-secondary-container: '#774200'
  tertiary: '#000709'
  on-tertiary: '#ffffff'
  tertiary-container: '#0f2126'
  on-tertiary-container: '#77898f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#fedcc8'
  primary-fixed-dim: '#e1c0ad'
  on-primary-fixed: '#29170c'
  on-primary-fixed-variant: '#594234'
  secondary-fixed: '#ffdcc0'
  secondary-fixed-dim: '#ffb876'
  on-secondary-fixed: '#2d1600'
  on-secondary-fixed-variant: '#6b3b00'
  tertiary-fixed: '#d2e6ec'
  tertiary-fixed-dim: '#b7cad0'
  on-tertiary-fixed: '#0c1e23'
  on-tertiary-fixed-variant: '#384a4f'
  background: '#fff8f5'
  on-background: '#241912'
  surface-variant: '#f4ded2'
typography:
  display-xl:
    fontFamily: Noto Serif
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  display-lg:
    fontFamily: Noto Serif
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Noto Serif
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-sm:
    fontFamily: Noto Serif
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  margin: 32px
  section-gap: 120px
  stack-sm: 16px
  stack-md: 32px
  stack-lg: 48px
---

## Brand & Style

This design system translates a 150-year-old Egyptian coffee legacy into a contemporary digital experience. The aesthetic is defined by "Warm Luxury"—a balance of historical weight and modern clarity. It draws heavily from **Minimalism** for its layout and **Tactile** design for its interactions, evoking the physical sensation of a high-end Cairo café.

The target audience seeks more than a commodity; they seek a ritual. To evoke this, the UI utilizes high-contrast pairings and generous whitespace, ensuring that the product and heritage stories remain the focal point. The emotional response is one of sophisticated comfort, reliability, and artisanal quality.

## Colors

The palette is rooted in the organic tones of the coffee-making process. The primary **Espresso** provides the structural depth and is used for primary typography and heavy UI elements to establish authority. The **Caramel** accent is used sparingly to draw attention to key actions and signify warmth. 

The **Cream** background is the canvas of the design system, replacing harsh whites with a softer, more premium parchment feel. For secondary text and borders, a muted neutral brown ensures legibility without breaking the monochromatic harmony of the brand.

## Typography

Typography acts as the primary bridge between the past and the present. **Noto Serif** is utilized for headlines and displays to echo the classic, established feel of the 150-year heritage. It should be typeset with generous leading to maintain an editorial, high-end look.

**Plus Jakarta Sans** provides a modern counterpoint for body copy and UI labels. Its clean, open apertures ensure high readability on digital screens while maintaining a friendly, welcoming tone. All uppercase labels should include slight letter-spacing to enhance the sophisticated, "gallery" feel of the interface.

## Layout & Spacing

This design system employs a **Fixed Grid** model centered within a 1280px maximum width container. This constraint ensures that the "spacious" luxury feel is maintained across all desktop resolutions, preventing content from becoming over-extended.

The spacing rhythm is built on an 8px baseline. Large vertical gaps (120px) are encouraged between major sections to allow the brand imagery and typography to "breathe," simulating the unhurried atmosphere of a premium café. Grids should typically follow a 12-column structure with 24px gutters for balanced content distribution.

## Elevation & Depth

Depth is conveyed through **Tonal Layers** rather than aggressive shadows. Surfaces are primarily flat, with elevation indicated by subtle shifts in the Cream background or thin, low-contrast borders in a lightened Espresso tone.

When shadows are necessary for functional depth (such as on active cards or dropdowns), they must be **Ambient Shadows**. These are extra-diffused, low-opacity, and tinted with the Primary Espresso color (#2C1A0E) to avoid a "muddy" gray appearance. This maintains the warm, organic aesthetic of the brand while providing clear z-axis cues.

## Shapes

The shape language reflects the duality of artisan craftsmanship—structured yet approachable. The system uses a **Rounded** base (Level 2), but applies specific radii to distinct component classes to create a clear visual hierarchy.

- **Structural Elements:** Such as cards and large containers, utilize a 16px (1rem) radius to feel substantial and grounded.
- **Interactive Elements:** Such as buttons, pills, and chips, utilize a 32px (2rem) radius. These fully-rounded shapes offer a soft, tactile invitation to touch, contrasting against the more rigid layout grid.

## Components

### Buttons & Pills
Buttons are the primary call-to-action. They feature a 32px border radius. Primary buttons use the Espresso background with Cream text. Secondary "Artisan" buttons utilize the Caramel accent to highlight specific promotions or premium offerings.

### Cards
Cards are defined by a 16px border radius. They should use a subtle 1px border in a muted neutral or a very soft ambient shadow to separate themselves from the Cream background. Image-heavy cards are preferred to showcase the "High-end Cairo" vibe.

### Input Fields
Inputs follow a 16px radius to match cards, emphasizing a unified structural language. The focus state is signaled by a 2px Caramel border.

### Chips & Tags
Used for coffee origins or flavor profiles (e.g., "Floral," "Dark Roast"), these follow the 32px pill shape. They should use low-contrast backgrounds with high-contrast text for a sophisticated, subtle look.

### Navigation
The top navigation should be centered or split, utilizing the 1280px grid. It remains transparent or uses a slight Cream frost to maintain a sense of lightness and space.